// fetch('http://localhost:3000/api/products')
// .then((item) => item.json())
// .then((item) => {
//     var panier = [item._id, item.colors];
//     document.querySelector('button').addEventListener('click', console.log(panier));
// })

console.log(localStorage.getItem('id_produit', 'couleur'));



