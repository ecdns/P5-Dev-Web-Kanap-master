let url = new URL(window.location.href);
let id_produit = url.searchParams.get('id');

let urlApi = `http://localhost:3000/api/products/${id_produit}`;
fetch(urlApi)
    .then((item) => item.json())
    .then((item) => {
        document.querySelector('.item__img').innerHTML += `<img src="${item['imageUrl']}" alt="Photographie d'un canapé"></img>`;
        document.querySelector('#price').innerHTML += item.price;
        document.querySelector('#title').innerHTML += item.name;
        document.querySelector('#description').innerHTML += item.description;
        for(i = 0; i < item.colors.length; i++){
            document.querySelector('#colors').innerHTML += '<option>' + item.colors[i] + '</option>';
        }
    });

document.querySelector('button').addEventListener('click', addtocart());

function addtocart(){
    fetch(urlApi)
        .then((item) => item.json())
        .then((item) => {
            if(!localStorage.getItem(item.id_produit)){
                let OptionsProduit = {
                    'id_produit' : JSON.stringify(item._id),
                    'couleur' : JSON.stringify(item.colors)
                }
                ProduitEnregistreDansLePanier = [];
                ProduitEnregistreDansLePanier.push(OptionsProduit);
                console.log(ProduitEnregistreDansLePanier);
            }else{
                console.log('déjà dans le panier');
            }
        })
}


// cart = {};
// function addtocart(cart){
//     fetch (urlApi)
//         .then((item) => item.json())
//         .then((item) => {
//             cart.push({'id_produit' : JSON.stringify(item._id), 'couleur': JSON.stringify(item.colors)});
//             localStorage += cart;
//         })
// }

